Copyright
--------------
WR-Nitro WordPress Theme, Copyright 2016 WooRockets.com
WR-Nitro is distributed under the terms of the GNU/GPL v2 or later


Install Steps
--------------
Step 1: Go to Appearance > Add New Themes, then click Upload button

Step 2: Go to browse, then select the wr-nitro.zip file

Step 3: Click "Install Now" to install Nitro

Step 4: Activate the newly installed Nitro by going to Appearance > Themes, find Nitro and click on "Activate" button

Step 5: Once Nitro is activated, you will be redirected to Nitro Welcome Screen. Switch to Plugins tab to install plugins.

Step 6: click "Install" to begin installing plugins. After that, you will have to activate plugins.


Link to download PSD package
--------------
http://bit.ly/nitro-psd-package